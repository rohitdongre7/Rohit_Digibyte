Building DigiByte
================

See doc/build-*.md for instructions on building the various
elements of the DigiByte Core reference implementation of DigiByte.
